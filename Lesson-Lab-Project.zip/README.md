# Lesson Lab

A locally run lesson-creation workspace for researching sources, drafting a 45-minute lesson, reviewing two separate quality-control reports, editing, previewing, and exporting the result.

## Requirements

- Node.js 20 or newer
- Internet access for live research discovery
- Optional API-compatible chat-completions provider credentials for AI-generated lessons and independent AI audits

## Run locally

```powershell
npm start
```

Open [http://localhost:3000](http://localhost:3000). No packages need to be installed.

Without an AI key, the app clearly labels its output as a generic starter lesson. It still attempts live research and creates two cautious review reports; this mode is useful for testing the interface, not as a substitute for topic-specific teaching content or fact-checking.

For AI generation, set the provider credentials in PowerShell before starting:

```powershell
$env:AI_API_KEY = "your-provider-key"
$env:AI_MODEL = "gpt-4o-mini"
# Optional: use an OpenAI-compatible chat-completions endpoint
$env:AI_API_URL = "https://api.openai.com/v1/chat/completions"
npm start
```

The server keeps API keys out of browser code. Each generation makes one lesson request and two separate audit requests—one for research/factual accuracy and one for instructional quality. A failed AI step is surfaced to the instructor, and the previous browser-saved draft remains intact.

For YouTube Data API video candidates, also set a key with access to the YouTube Data API:

```powershell
$env:YOUTUBE_API_KEY = "your-youtube-data-api-key"
npm start
```

Without that key, the research library includes a YouTube search link rather than claiming that any specific video has been reviewed.

### Research sources

- Wikipedia's public API provides web reference candidates and short extracts.
- Open Library's search API provides candidate book records; it does not guarantee that the book is accessible or authoritative for a particular claim.
- Without `YOUTUBE_API_KEY`, the app supplies a clearly labeled YouTube search link rather than claiming that a specific video has been reviewed. To retrieve video candidates, set a YouTube Data API key.
- Network failures are shown as warnings; the app does not silently represent failed research as verified research.

Every source and generated claim must be checked by the instructor. Automated QC is an aid, not a guarantee of accuracy. Prompts ask the model to synthesize rather than copy reference text, but instructors should still check for unattributed quotations or close paraphrases. External resources are linked and should be acknowledged when used.

## Use the workflow

1. Enter a lesson title and measurable learning objective, or load either sample.
2. Choose **Research & create lesson**. Research is performed server-side; if configured, the AI produces a lesson and two independent audit reports.
3. Review the **Lesson**, **Research QC**, and **Teaching QC** tabs. Open and inspect the references.
4. Edit the lesson directly. Changes and form inputs autosave to this browser's local storage.
5. Use **Preview** to inspect the lesson, and apply QC recommendations to add them to the editable draft for instructor review.
6. Choose **Export lesson** to download a Markdown file containing the final edited lesson, references, and both QC reports.

The fixed lesson schedule is 3 + 12 + 8 + 12 + 7 + 3 minutes = 45 minutes. Generated lesson content should retain this time budget; revise it if the actual learner pace or class needs differ.

## Screenshots

These screenshots show the HTTP lesson workflow, including the research library and the two separate QC reports. This capture uses starter mode because no AI provider key was configured; the draft is intentionally labeled and should not be presented as AI-generated or fact-verified content.

### Lesson and research library

![Lesson preview and research references](screenshots/01-lesson-overview.png)

### Research and factual accuracy review

![Research quality-control report](screenshots/02-research-quality-check.png)

### Instructional quality review

![Instructional quality-control report](screenshots/03-instructional-quality-check.png)

## Demo walkthrough

For a short screen recording, load the HTTP sample, generate the lesson, show the research library and both QC tabs, apply a recommendation, edit the lesson, switch to Preview, then export the Markdown. Explain that sources are candidates for instructor review, the AI key stays on the local server, and the two audits use separate prompts. Repeat with the Photosynthesis sample if time permits.

## Test

```powershell
npm test
```

The tests cover required-input validation, distinct research queries, the 45-minute lesson schedule, and the two separate review dimensions.
